#ifndef GUARD_HEADERONLY_H
#define GUARD_HEADERONLY_H

#include <stdio.h>

#endif