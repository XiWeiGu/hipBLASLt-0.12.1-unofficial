+++++++++++++++++++++++
 Useful Documentation 
+++++++++++++++++++++++

``Useful`` is a library providing undeniably useful functionality for developing
awesome applications.
