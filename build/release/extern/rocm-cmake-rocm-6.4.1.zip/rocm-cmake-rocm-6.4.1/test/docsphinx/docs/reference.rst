API Reference
=============

The exhaustive list of awesomeness is as follows:

.. doxygengroup:: public_api
