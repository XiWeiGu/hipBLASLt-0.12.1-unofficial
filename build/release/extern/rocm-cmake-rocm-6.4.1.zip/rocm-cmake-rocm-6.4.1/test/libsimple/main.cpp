
void simple();

int main() {
    simple();
}
