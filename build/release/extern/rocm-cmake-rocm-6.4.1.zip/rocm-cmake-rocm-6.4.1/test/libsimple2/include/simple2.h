/*******************************************************************************
 * Copyright (C) 2017 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_SIMPLE_H
#define GUARD_SIMPLE_H

#include <simple.h>

void simple2();


#endif
