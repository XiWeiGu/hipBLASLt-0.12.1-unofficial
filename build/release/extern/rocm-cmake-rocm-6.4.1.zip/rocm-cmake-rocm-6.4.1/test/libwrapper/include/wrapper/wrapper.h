/*******************************************************************************
 * Copyright (C) 2022 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_WRAPPER_H
#define GUARD_WRAPPER_H

void wrapper();


#endif
