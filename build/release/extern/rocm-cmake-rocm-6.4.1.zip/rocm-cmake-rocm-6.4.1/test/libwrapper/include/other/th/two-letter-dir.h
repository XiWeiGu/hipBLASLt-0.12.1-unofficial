/*******************************************************************************
 * Copyright (C) 2022 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_TWO_LETTER_DIR_H
#define GUARD_TWO_LETTER_DIR_H

void tld();


#endif
