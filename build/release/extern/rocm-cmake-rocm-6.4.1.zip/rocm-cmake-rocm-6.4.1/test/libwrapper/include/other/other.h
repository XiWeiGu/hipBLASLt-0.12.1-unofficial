/*******************************************************************************
 * Copyright (C) 2022 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_OTHER_H
#define GUARD_OTHER_H

#include "th/two-letter-dir.h"

void other();


#endif
