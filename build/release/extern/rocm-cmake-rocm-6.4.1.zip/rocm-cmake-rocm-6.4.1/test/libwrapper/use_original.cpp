#include "wrapper/wrapper.h"
#include "other/other.h"

int main() {
    wrapper();
}
