#include "wrapper.h"
#include "other.h"


int main() {
    wrapper();
}
