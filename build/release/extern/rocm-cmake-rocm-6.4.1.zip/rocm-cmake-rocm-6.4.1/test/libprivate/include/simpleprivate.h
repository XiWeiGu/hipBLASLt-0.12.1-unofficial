/*******************************************************************************
 * Copyright (C) 2024 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_SIMPLE_PRIVATE_H
#define GUARD_SIMPLE_PRIVATE_H

void simple_private();


#endif
