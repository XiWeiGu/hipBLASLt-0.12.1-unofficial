
void simple_private();

int main() {
    simple_private();
}
