/*******************************************************************************
 * Copyright (C) 2020 Advanced Micro Devices, Inc.
 ******************************************************************************/


#ifndef GUARD_BASIC_H
#define GUARD_BASIC_H

void basic();


#endif
